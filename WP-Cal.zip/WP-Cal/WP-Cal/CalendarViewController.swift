//
//  CalendarViewController.swift
//  WP-Cal
//
//  Created by busdev on 12/12/2017.
//  Copyright © 2017 FAV Software Limited. All rights reserved.
//

// Displays a monthly calendar using the WPCalendar data source.
// The user may select either one or two days. Two days are
// selected by first double tapping on the first month day, then
// tapping once on the second month day.
// A single day is selected by tapping the desired omnth day once.
// Spoken help is available by tapping the information icon placed
// at the top left of the screen.

import UIKit
import CoreData

class CalendarViewController: UIViewController,UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource
{
 @IBOutlet weak var calendarList: UITableView!
 @IBOutlet weak var titleSVLeading: NSLayoutConstraint!
 @IBOutlet weak var titleSVTrailing: NSLayoutConstraint!
 
 var tableRefreshTimer: Timer!
 var preDisplay: Bool!
 var shouldScrollMidway: Bool!
 var screenDisplayed: Bool!
 
 var calItemHeight: CGFloat?
 var calItemWidth: CGFloat?
 var calMonthTitleViewHeight: CGFloat?
 var calMonthTitleLabelViewHeight: CGFloat?
 var calMonthTitlelabelYOffet: CGFloat?
 var calXInset:CGFloat?
 var calItemSpacing: CGFloat?
 
 var lastVisibleTopIndexPath: IndexPath?
 
 var day1JDN: Int = 0  // Selected using single tap.
 var day2JDN: Int = 0  // Selected using double tap.
 
 let tts: TTS = TTS()
 
// Constants.
 
 let WPCalendarVCQueue = DispatchQueue(label: "WPCalendarVCQueue",attributes: DispatchQueue.Attributes.concurrent)
 
 let kHelpStr: String = """
                          Welcome to the monthly calendar. You may select either one or two calendar days.
                          To select a single day, tap your selected month day once. To select two days,
                          tap the first month day twice, then tap the second month day once.
                        """
 
 let kTitleLine: String       = "Title"
 let kWeekDetailsLine: String = "Week Details"
 
 let kTitleLeadingSpaceCompact: CGFloat = 15.0   // 10.0
 let kTitleLeadingSpaceRegular: CGFloat = 150.0  // 75.0
 
 let kCalendarTitleItemWidth: CGFloat = 34.0     // Width of day of week text field.
 let kCalendarTitleLineHeight: CGFloat = 50.0
 let kItemSpaceRatio: CGFloat = 0.2              // 0.15
 let kItemMinSpace: CGFloat = 2.0
 
 let kCalendarCellColor            = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 0.0)
 let kCalendarCurrentDayCellColor  = UIColor(red: 255/255, green: 0/255, blue: 0/255, alpha: 1.0)
 let kCalendarSelectedDayCellColor = UIColor(red: 211/255, green: 211/255, blue: 211/255, alpha: 1.0)
 let kCalendarCellBorderColor      = UIColor(red: 50/255, green: 50/255, blue: 50/255, alpha: 0.5)

 override func viewDidLoad()
 {
  super.viewDidLoad()
  
  NotificationCenter.default.addObserver(
   self,
   selector: #selector(CalendarViewController.orientationChanged),
   name: NSNotification.Name.UIDeviceOrientationDidChange,
   object: nil)

  preDisplay = true  // Make sure that calendar table is correctly displayed WHEN view appears.
  
  printDbg(k.kDomainCalendarUI, str: "Calendar VC at viewDidLoad().")
  
  calendarList.delegate   = self
  calendarList.dataSource = self
  
  shouldScrollMidway = true  // Keep positioning the table midway until it is scrolled.
 }
 
 override func viewDidAppear(_ animated: Bool)
 {
  super.viewDidAppear(animated)
  
  preDisplay = false
  
  printDbg(k.kDomainCalendarUI, str: "Calendar VC at viewDidAppear().")
  
  startLoadingData()
 }
 
 override func viewWillDisappear(_ animated: Bool)
 {
  if let _ = tts.ss
  {
   tts.stopSpeaking()
  }
 }
 
 @objc func startLoadingData()
 {
  printDbg(k.kDomainCalendarUI, str: "Calendar VC at startLoadingData().")
  
  calendarList.alpha = 0
  setHeightsAndWidths()
  screenDisplayed = true
  reloadTableData()
  
  let viewAlphaAnimator = UIViewPropertyAnimator(duration: 0.5,
                                                 curve: .linear,
                                                 animations: { self.calendarList.alpha = 1 })
  viewAlphaAnimator.startAnimation()
 }
 
 override func viewDidDisappear(_ animated: Bool)
 {
  printDbg(k.kDomainCalendarUI, str: "Calendar VC at viewDidDisappear().")
  
  calendarList.alpha = 0
  screenDisplayed = false
 }
 
 override func didReceiveMemoryWarning()
 {
  super.didReceiveMemoryWarning()
  
// Dispose of any resources that can be recreated.
  
 }
 
// Detect user scrolling the table and disable automatic centering of calendar.
 
 func scrollViewWillBeginDragging(_ scrollView: UIScrollView)
 {
  shouldScrollMidway = false
 }
 
 @IBAction func helpButtonTapped(_ sender: Any)
 {
  tts.textToSpeech(spokenStr: kHelpStr)
 }
 
 @IBAction func nowButtonTapped(_ sender: Any)
 {
  shouldScrollMidway = true  // Keep positioning the table midway until it is scrolled.
  scrollToDay()
 }
 
// Use orientation and regular/compact size class to
// determine the heights and widths of custom items.
 
 func setHeightsAndWidths()
 {
  var sizeClass: String?
  
  printDbg(k.kDomainCalendarUI, str: "At Calendar VC: setHeightsAndWidths().")
  
  if (self.view.traitCollection.horizontalSizeClass == UIUserInterfaceSizeClass.compact)
  {
   sizeClass = "C"
  }
  else
  {
   sizeClass = "R"
  }
  
  var calendarWidth: CGFloat  = calendarList.frame.width   // Changed from screen width to table view width.
  let calendarHeight: CGFloat = calendarList.frame.height
  var leadingWidth: CGFloat   = titleSVLeading.constant
  var screenOrientation: String = "P"
  
  switch UIDevice.current.orientation
  {
   case .portrait:       screenOrientation = "P"
   case .landscapeLeft:  screenOrientation = "L"
   case .landscapeRight: screenOrientation = "L"
   
   default: break
  }
  
// Check that calendar width is correct and not transposed with calendar height.
  
  printDbg(k.kDomainCalendarUI, str: "Calendar width: \(calendarWidth), height: \(calendarHeight).")
  
  if (screenOrientation == "P")
  {
   if (calendarHeight < calendarWidth)
   {
    calendarWidth = calendarHeight
   }
  }
  else
  {
   if (calendarHeight > calendarWidth)
   {
    calendarWidth = calendarHeight
   }
  }
  
  if (sizeClass == "C")
  {
   (screenOrientation == "P") ? (leadingWidth = kTitleLeadingSpaceCompact) : (leadingWidth = kTitleLeadingSpaceCompact * 8.0)   // 10.0
  }
  else
  {
   (screenOrientation == "P") ? (leadingWidth = kTitleLeadingSpaceRegular) : (leadingWidth = kTitleLeadingSpaceRegular * 1.5)   // 2.5
  }
  
  printDbg(k.kDomainCalendarUI, str: "Title leading edge: \(leadingWidth).")
  printDbg(k.kDomainCalendarUI, str: "Orientation: \(screenOrientation). Size class: \(sizeClass!). Screen width: \(calendarWidth).")
  
  titleSVLeading.constant  = leadingWidth
  titleSVTrailing.constant = leadingWidth
  
// mw is the distance between the centers of the first and last day of week text fields.
// Mon and Sun.
  
  let mw: CGFloat = calendarWidth - (2 * leadingWidth) - kCalendarTitleItemWidth
  
  calItemWidth = mw/(6 * (1 + kItemSpaceRatio))
  calXInset = (leadingWidth + (kCalendarTitleItemWidth/2)) - (calItemWidth!/2)
  
  calItemSpacing = calItemWidth! * kItemSpaceRatio
  
  calItemWidth = ceil(calItemWidth!)
  calItemHeight = calItemWidth
  calItemSpacing = ceil(calItemSpacing!)
  calXInset = ceil(calXInset!)
  
  printDbg(k.kDomainCalendarUI, str: "Inter-item spacing (1): \(calItemSpacing!).")
  
// Correction calculations. The space between the calendar days is adjusted
// due to the rounding up of calItemWidth and calItemSpacing.
  
  let newMw: CGFloat = ((6 * calItemWidth!) * (1 + kItemSpaceRatio))
  let mwDiff: CGFloat = ceil(newMw - mw)
  
  calItemSpacing = floor(calItemSpacing! - (mwDiff/6))
  
  if (calItemSpacing! < kItemMinSpace)
  {
   calItemSpacing = kItemMinSpace
  }
  
  calMonthTitleViewHeight = kCalendarTitleLineHeight
  calMonthTitleLabelViewHeight = 25
  calMonthTitlelabelYOffet = 10
  
  printDbg(k.kDomainCalendarUI, str: "X Inset: \(calXInset!). Item Width: \(calItemWidth!). Inter-item spacing (2): \(calItemSpacing!).")
 }
 
// Table related functions.
 
 func numberOfSections(in tableView: UITableView) -> Int
 {
  return 1
 }

// Returns number of calendar lines.

 func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
 {
  if (preDisplay == true)  // Not yet ready to display table.
  {
   return 0
  }
  else
  {
   let rowCount = WPCal.ds.count

   return (rowCount > 0) ? rowCount : 1
  }
 }
 
 func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
 {
  let cellIDStr = "cell"
  let cell: UITableViewCell = tableView.dequeueReusableCell(withIdentifier: cellIDStr)!
  
  var CL: CalendarLine?
  var titleView: UIView?
  var titleLab: UILabel?
  var dataAvailable: Bool = false
  
// Save the visible index path at the top. This is used to re-scroll
// the table after the device's orientation is changed.
  
  lastVisibleTopIndexPath = tableView.indexPathsForVisibleRows!.first
 
  if (WPCal.ds.count > indexPath.row)
  {
   CL = WPCal.ds[indexPath.row]
   dataAvailable = true
  }
 
  cell.selectionStyle = .none; // Ensure that cell (row) can not be selected.
 
// Remove any existing subviews from cell's content view.
 
  for subView in cell.contentView.subviews
  {
   subView.removeFromSuperview()
  }
 
  var cellRect: CGRect?
  var labelRect: CGRect?
 
// Populate cell's contents.
 
  if (dataAvailable)
  {
   if (CL!.lineType == kTitleLine)
   {
    cellRect = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: calMonthTitleViewHeight!)
    titleView = UIView(frame: cellRect!)
   
    labelRect = CGRect(x: 0, y: calMonthTitlelabelYOffet!, width: self.view.frame.size.width, height: calMonthTitleLabelViewHeight!)
    titleLab = UILabel(frame: labelRect!)
    titleLab!.text = "\(CL!.monthStr!) \(CL!.yearStr!)"
    titleLab!.textAlignment = .center
   
    titleView?.addSubview(titleLab!)
 
// Increase the font size of the month/year title.
 
    let font: UIFont = titleLab!.font
    titleLab!.font = font.withSize(font.pointSize + 2)   // V2.1 Changed from 1 to 2.
 
    cell.contentView.addSubview(titleView!)
   }
   else
   {
    cellRect = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: calItemHeight!)
    let lineView: UIView = UIView(frame: cellRect!)
    addCalendarItemsToLine(lineView, CL: CL!)
    cell.contentView.addSubview(lineView)
   }
  }
 
  return cell
 }

 func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
 {
  var CL: CalendarLine?
  var cellHeight: CGFloat = 0.0
 
  if (WPCal.ds.count > indexPath.row)
  {
   CL = WPCal.ds[indexPath.row]
 
   if (CL!.lineType == kTitleLine)
   {
    cellHeight = calMonthTitleViewHeight!
   }
   else
   {
    cellHeight = calItemHeight! + calItemSpacing!
   }
  }
 
  return cellHeight
 }
 
 func addCalendarItemsToLine(_ lineView: UIView, CL: CalendarLine)
 {
  var xOffset: CGFloat = calXInset!
  let xSpacer: CGFloat = calItemWidth! + calItemSpacing!
 
  if let _ = CL.mon
  {
   lineView.addSubview(createCalendarCell(CL.mon!, xOffset: xOffset))
  }
  xOffset += xSpacer
  
  if let _ = CL.tue
  {
   lineView.addSubview(createCalendarCell(CL.tue!, xOffset: xOffset))
  }
  xOffset += xSpacer
  
  if let _ = CL.wed
  {
   lineView.addSubview(createCalendarCell(CL.wed!, xOffset: xOffset))
  }
  xOffset += xSpacer
  
  if let _ = CL.thu
  {
   lineView.addSubview(createCalendarCell(CL.thu!, xOffset: xOffset))
  }
  xOffset += xSpacer
  
  if let _ = CL.fri
  {
   lineView.addSubview(createCalendarCell(CL.fri!, xOffset: xOffset))
  }
  xOffset += xSpacer
  
  if let _ = CL.sat
  {
   lineView.addSubview(createCalendarCell(CL.sat!, xOffset: xOffset))
  }
  xOffset += xSpacer
  
  if let _ = CL.sun
  {
   lineView.addSubview(createCalendarCell(CL.sun!, xOffset: xOffset))
  }
 }

// Construct calendar cell using xOffset and calendar item.
 
 func createCalendarCell(_ CI: CalendarItem, xOffset: CGFloat) -> UIView
 {
  let calCellView: UIView = UIView(frame: CGRect(x: xOffset, y: 0, width: calItemWidth!, height: calItemHeight!).integral)
  let calCellLabel: UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: calItemWidth!, height: calItemHeight!).integral)
  
  var fillColor: UIColor = kCalendarCellColor
  
  if (CI.itemDate!.isToday() == true)
  {
   fillColor = kCalendarCurrentDayCellColor
  }
  
  if (day2JDN != 0) && (CI.itemJDN! == day2JDN)
  {
   fillColor = kCalendarSelectedDayCellColor
  }
  
  let calCellImage: UIImage = cellImage(fillColor)
  let cellImageView = UIImageView(frame: CGRect(x: 0, y: 0, width: calItemWidth!, height: calItemHeight!).integral)
  cellImageView.image = calCellImage
  
  calCellLabel.text = "\(CI.dayOfMonth!)"
  calCellLabel.textAlignment = .center
  
  let dateDayNumberFormatter: DateFormatter = DateFormatter()
  let enUSPOSIXLocale: Locale = Locale(identifier: "en_US_POSIX")
  dateDayNumberFormatter.locale = enUSPOSIXLocale
  dateDayNumberFormatter.dateFormat = "c"
  
  let dayNumber: Int = Int(dateDayNumberFormatter.string(from: CI.itemDate! as Date))!
  
  if (dayNumber == 1) || (dayNumber == 7)
  {
   calCellLabel.textColor = UIColor.darkGray
  }
  else
  {
   calCellLabel.textColor = UIColor.black
  }
 
// Gesture recognizers - single and double tap.
  
  let singleCalendarCellTap:UITapGestureRecognizer =
                UITapGestureRecognizer(target:self,
                                       action: #selector(CalendarViewController.calendarCellSingleTapped(_:)))
  
  singleCalendarCellTap.numberOfTapsRequired = 1
 
  let doubleCalendarCellTap:UITapGestureRecognizer =
                UITapGestureRecognizer(target:self,
                                       action: #selector(CalendarViewController.calendarCellDoubleTapped(_:)))
  
  doubleCalendarCellTap.numberOfTapsRequired = 2

  calCellView.isUserInteractionEnabled = true
  calCellView.tag = CI.itemJDN!                                 // Set tag to julian day number.
  calCellView.addGestureRecognizer(doubleCalendarCellTap)
  calCellView.addGestureRecognizer(singleCalendarCellTap)
  
  singleCalendarCellTap.require(toFail: doubleCalendarCellTap)

  calCellView.addSubview(cellImageView)
  calCellView.addSubview(calCellLabel)
  
  return calCellView
 }
 
 func cellImage(_ fillColor: UIColor) -> UIImage
 {
  let rect: CGRect = CGRect(x: 0, y: 0, width: calItemWidth!, height: calItemHeight!).integral
  let bezierPath: UIBezierPath = UIBezierPath(rect: rect)

  UIGraphicsBeginImageContext(rect.size)
  
  let context = UIGraphicsGetCurrentContext()
  
  context?.saveGState()
  context?.addPath(bezierPath.cgPath)
  
  let strokeColor: UIColor = kCalendarCellBorderColor
  let strokeWidth: CGFloat = ceil((3.0/100) * calItemWidth!)  // 1.0
  
  strokeColor.setStroke()
  context?.setLineWidth(strokeWidth)
  
  let imageFillColor: UIColor = fillColor
  
  imageFillColor.setFill()
  context?.drawPath(using: .fillStroke)
  
  let image = UIGraphicsGetImageFromCurrentImageContext()
  
  context?.restoreGState()
  UIGraphicsEndImageContext()
  
  return image!
 }
 
 @objc func calendarCellSingleTapped(_ sender: UITapGestureRecognizer)
 {
  printDbg(k.kDomainCalendarUI, str: "At calendarCellSingleTapped().")
  
  day1JDN = sender.view!.tag
  shouldScrollMidway = true
  
  performSegue(withIdentifier: "calendarDay", sender: nil)
 }
 
 @objc func calendarCellDoubleTapped(_ sender: UITapGestureRecognizer)
 {
  printDbg(k.kDomainCalendarUI, str: "At calendarCellDoubleTapped().")
  
  day2JDN = sender.view!.tag
  shouldScrollMidway = true
  calendarList.reloadData()          // Re-display calendar.
 }

// Update the calendar datastructure in the background.
// Reload the table's data in the foreground.
 
 func reloadTableData()
 {
  if (WPCal.updatingCalendarDataSource == false)
  {
   WPCalendarVCQueue.async {
    WPCal.updateCalendar()
    DispatchQueue.main.async {
     self.calendarList.reloadData()
     
     if (self.shouldScrollMidway == true)
     {
      self.scrollToDay()
     }
    }
   }
  }
 }
 
// Scrolls to the user selected day or if no day selected, to the middle of the list.
 
 func scrollToDay()
 {
  var lineCount: Int = 0
  var lineFound: Bool = false
  var targetJDN: Int = day1JDN
  
  if (targetJDN == 0)
  {
   let dateJDNFormatter: DateFormatter = DateFormatter()   // Julian day number date formatter.
   
   dateJDNFormatter.dateFormat = "g"
   targetJDN = Int(dateJDNFormatter.string(from: Date()))! // Today's julian date.
  }
  
  printDbg(k.kDomainCalendarUI, str: "At scrollToDay().")
  
  if (WPCal.updatingCalendarDataSource == false)
  {
   printDbg(k.kDomainCalendarUI, str: "Attempting to scroll the table view. Selected Julian Day: \(day1JDN)")
   
   if (WPCal.ds.count > 1)
   {
    for cl in WPCal.ds
    {
     if (cl.lineType == kWeekDetailsLine)
     {
      if let _ = cl.mon
      {
       if (targetJDN == cl.mon!.itemJDN) { lineFound = true; break }
      }
      if let _ = cl.tue
      {
       if (targetJDN == cl.tue!.itemJDN) { lineFound = true; break }
      }
      if let _ = cl.wed
      {
       if (targetJDN == cl.wed!.itemJDN) { lineFound = true; break }
      }
      if let _ = cl.thu
      {
       if (targetJDN == cl.thu!.itemJDN) { lineFound = true; break }
      }
      if let _ = cl.fri
      {
       if (targetJDN == cl.fri!.itemJDN) { lineFound = true; break }
      }
      if let _ = cl.sat
      {
       if (targetJDN == cl.sat!.itemJDN) { lineFound = true; break }
      }
      if let _ = cl.sun
      {
       if (targetJDN == cl.sun!.itemJDN) { lineFound = true; break }
      }
     }
     lineCount += 1
    }
   }
  }
  if (lineFound == true)
  {
   let indexPath = IndexPath(row:lineCount, section: 0)
   calendarList.scrollToRow(at: indexPath, at: UITableViewScrollPosition.middle, animated: false)
  }
  else
  {
   if (WPCal.ds.count > 1)
   {
    let indexPath = IndexPath(row:WPCal.ds.count/2, section: 0)
    calendarList.scrollToRow(at: indexPath, at: UITableViewScrollPosition.middle, animated: false)
   }
  }
 }
 
// When device orientation has changed:
// Recalculate widths and heights of cell items and spacing.
// Reload the table and scroll back to the last visible top index path.
 
 @objc func orientationChanged()
 {
  if (UIDevice.current.orientation != .portraitUpsideDown)
  {
   printDbg(k.kDomainGeneral, str: "Calendar: Orientation changed.")
   
   displayCalendarDays()
  }
 }
 
// Display calendar days, centering the calendar on either week of the selected day,
// or the last visible week.
 
 func displayCalendarDays()
 {
  printDbg(k.kDomainCalendarUI, str: "At displayCalendarDays().")
  
  calendarList.alpha = 0
  setHeightsAndWidths()
  calendarList.reloadData()

  if (shouldScrollMidway == true)
  {
   scrollToDay()
  }
  else
  {
   if let _ = lastVisibleTopIndexPath
   {
    calendarList.scrollToRow(at: lastVisibleTopIndexPath!, at: UITableViewScrollPosition.top, animated: false)
   }
  }
  
  if (screenDisplayed == true)
  {
   let viewAlphaAnimator = UIViewPropertyAnimator(duration: 0.5,
                                                  curve: .linear,
                                                  animations: { self.calendarList.alpha = 1 })
   viewAlphaAnimator.startAnimation()
  }
 }
 
// MARK: - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
 
 override func prepare(for segue: UIStoryboardSegue, sender: Any?)
 {
  let vc = segue.destination
 
// Get the new view controller using segue.destinationViewController.
// Set the calendar day julian numbers and presenting view controller.
 
  if (vc.className == "CalendarDayViewController")
  {
   let calendarDayVC: CalendarDayViewController = segue.destination as! CalendarDayViewController
 
   calendarDayVC.calendarDay1JDN = day1JDN
   calendarDayVC.calendarDay2JDN = day2JDN
   
   day2JDN = 0  // Reset date to allow user the option of selecting a single date only.
  }
 }

}
