//
//  K.swift
//  WP-Cal
//
//  Created by busdev on 12/12/2017.
//  Copyright © 2017 FAV Software Limited. All rights reserved.
//

import UIKit

public let k = K()

open class K: NSObject
{
 
// Constants.
 
 let kDomainGeneral: Int    = 0
 let kDomainCalendarUI: Int = 1
 let kDomainSpeech: Int     = 2
 
 let kNo: Int  = 0
 let kYes: Int = 1
 
 let fieldRadius: CGFloat = 4.5
 let fieldIndent: CGFloat = 5.0
 let topPadding: CGFloat = 1.0
 let bottomPadding: CGFloat = 3.0

 let textViewCornerRadius: CGFloat = 5.0
 let textViewBorderWidth: CGFloat  = 1.0
 
 let kTitleLine: String       = "Title"
 let kWeekDetailsLine: String = "Week Details"
 
 let kSlotTypeTitle: String = "Title"
 let kSlotTypeTime: String  = "Time"
 
 let kPreUtteranceDelay: Double  = 0.15      // Pre utterance delay (text to speech).
 let kPostUtteranceDelay: Double = 0.15      // Post utterance delay (text to speech).
 let kLowVolume: Float           = 0.50
 let kMediumVolume: Float        = 0.75
 let kHighVolume: Float          = 1.0
}

