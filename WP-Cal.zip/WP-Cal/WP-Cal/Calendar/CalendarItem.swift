//
//  CalendarItem.swift
//  WP-Cal
//
//  Created by busdev on 12/12/2017.
//  Copyright © 2017 FAV Software Limited. All rights reserved.
//

// Calendar day of month.

import Foundation
import UIKit

class CalendarItem
{
 var itemDate: Date?
 var itemJDN: Int?
 var dayOfMonth: Int?
 
 init(_ calendarDate: Date, julianDayNumber: Int)
 {
  self.itemDate = calendarDate
  self.itemJDN  = julianDayNumber
  
  let cal = Calendar.current
  let unit:NSCalendar.Unit = .day
  let components: DateComponents = (cal as NSCalendar).components(unit, from: self.itemDate!)

  self.dayOfMonth = components.day
 }
}
