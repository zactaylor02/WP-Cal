//
//  WPCalendar.swift
//  WP-Cal
//
//  Created by busdev on 12/12/2017.
//  Copyright © 2017 FAV Software. All rights reserved.
//

// Data source for monthly calendar.

import UIKit

public let WPCal = WPCalendar()

open class WPCalendar: NSObject
{
 var updatingCalendarDataSource: Bool = false
 
 var ds = [CalendarLine]()  // Data source pointer used by CalendarViewController.
 var dsCount: Int = 0
 
 var calendarStartDate:  Date
 var calendarEndDate:    Date                // 24 months after calendar start date.
 var calendarStartJDN:   Int                   // Julian Day Number.
 var calendarEndJDN:     Int
 var currentCalendarJDN: Int
 
 var dateDayNumberFormatter: DateFormatter
 var dateMonthFormatter:     DateFormatter
 var dateYearFormatter:      DateFormatter
 var dateJDNFormatter:       DateFormatter   // Julian day number date formatter.
 
 // Initialize the date formaters, calendar start/end dates and calendar skeleton.
 // Note: after populating the calendar, the dates are re-initialized.
 
 fileprivate override init()
 {
  printDbg(k.kDomainCalendarUI, str: "Initializing Calendar.")
  
  let enUSPOSIXLocale: Locale = Locale(identifier: "en_US_POSIX")
  
  self.dateDayNumberFormatter = DateFormatter()
  self.dateMonthFormatter     = DateFormatter()
  self.dateYearFormatter      = DateFormatter()
  self.dateJDNFormatter       = DateFormatter()
  
  self.dateDayNumberFormatter.locale = enUSPOSIXLocale
  self.dateMonthFormatter.locale = Locale.current
  self.dateYearFormatter.locale = enUSPOSIXLocale
  self.dateJDNFormatter.locale = enUSPOSIXLocale
  
  self.dateDayNumberFormatter.dateFormat = "c"
  self.dateMonthFormatter.dateFormat     = "MMMM"
  self.dateYearFormatter.dateFormat      = "yyyy"
  self.dateJDNFormatter.dateFormat       = "g"
  
  self.calendarStartDate = Date().addYears(-2)
  self.calendarEndDate   = Date().addYears(2)
  
  calendarStartJDN   = Int(dateJDNFormatter.string(from: calendarStartDate))!
  calendarEndJDN     = Int(dateJDNFormatter.string(from: calendarEndDate))!
  currentCalendarJDN = calendarStartJDN
  
  super.init()
  
  populateCalendar()
  
  calendarStartJDN   = Int(dateJDNFormatter.string(from: calendarStartDate))!
  calendarEndJDN     = Int(dateJDNFormatter.string(from: calendarEndDate))!
  currentCalendarJDN = calendarStartJDN
 }
 
 func clearDataSource()
 {
  ds.removeAll()
 }
 
 // Called from calendar view controller.
 
 func updateCalendar()
 {
  printDbg(k.kDomainCalendarUI, str: "At updateCalendar().")
  
  updatingCalendarDataSource = true
  
  let startDate: Date = Date().addYears(-2)
  let startJDN: Int = Int(dateJDNFormatter.string(from: startDate))!
  
  if (startJDN != calendarStartJDN)
  {
   calendarStartDate = Date().addYears(-2)
   calendarEndDate   = Date().addYears(2)
   
   calendarStartJDN   = Int(dateJDNFormatter.string(from: calendarStartDate))!
   calendarEndJDN     = Int(dateJDNFormatter.string(from: calendarEndDate))!
   currentCalendarJDN = calendarStartJDN
   
   clearDataSource()
   populateCalendar()
  }
  
  updatingCalendarDataSource = false
 }
 
 func populateCalendar()
 {
  printDbg(k.kDomainCalendarUI, str: "At populateCalendar().")
  
  populateTitleCalendarLine()
  
  while (self.currentCalendarJDN <= self.calendarEndJDN)
  {
   if (populateWeekCalendarLine() == true)
   {
    populateTitleCalendarLine()
   }
  }
  
// Add empty week line to allow for scrolling to last week.
// Circumvents iOS feature.
  
  let CL: CalendarLine = CalendarLine()
  
  let currentCalendarJDNStr: String = "\(currentCalendarJDN)"
  let currentDate: Date = dateJDNFormatter.date(from: currentCalendarJDNStr)!
  
  CL.lineType = k.kWeekDetailsLine
  CL.monthStr = dateMonthFormatter.string(from: currentDate)
  CL.yearStr  = dateYearFormatter.string(from: currentDate)
  
  ds.append(CL)
 }
 
 func populateTitleCalendarLine()
 {
  let CL: CalendarLine = CalendarLine()
  
  let currentCalendarJDNStr: String = "\(currentCalendarJDN)"
  let currentDate: Date = dateJDNFormatter.date(from: currentCalendarJDNStr)!
  
  CL.lineType = k.kTitleLine
  CL.monthStr = dateMonthFormatter.string(from: currentDate)
  CL.yearStr  = dateYearFormatter.string(from: currentDate)
  
  ds.append(CL)
 }
 
// Populate a line of the calendar.
// Returns YES if month changed.
 
 func populateWeekCalendarLine() -> Bool
 {
  var daysLeft: Bool = true
  let startJDN: Int = self.currentCalendarJDN
  var dayNumber: Int = 0
  var monthStr: String = ""
  
  let CL: CalendarLine = CalendarLine()
  
  var currentCalendarJDNStr: String = "\(currentCalendarJDN)"
  var currentDate: Date = dateJDNFormatter.date(from: currentCalendarJDNStr)!
  
  CL.lineType = k.kWeekDetailsLine
  CL.monthStr = dateMonthFormatter.string(from: currentDate)
  CL.yearStr  = dateYearFormatter.string(from: currentDate)
  
  while(daysLeft == true)
  {
   populateCalendarItem(CL, currentDate: currentDate, currentJDN:currentCalendarJDN)
   
   currentCalendarJDN += 1 // Increment current calendar day.
   
   currentCalendarJDNStr = "\(currentCalendarJDN)"
   currentDate = dateJDNFormatter.date(from: currentCalendarJDNStr)!
   
   monthStr  = dateMonthFormatter.string(from: currentDate)
   dayNumber = Int(dateDayNumberFormatter.string(from: currentDate))!
   
   if ((currentCalendarJDN > calendarEndJDN) ||
    ((currentCalendarJDN != startJDN) && (dayNumber == 2)) ||
    (CL.monthStr != monthStr))
   {
    daysLeft = false
   }
  }
  
  ds.append(CL)
  
// Return YES if month has changed AND there are days to display in the "next" month.
  
  if ((CL.monthStr == monthStr) || (self.currentCalendarJDN > self.calendarEndJDN))
  {
   return false
  }
  else
  {
   return true
  }
 }
 
 func populateCalendarItem(_ CL: CalendarLine, currentDate: Date, currentJDN: Int)
 {
  let dayNumber: Int = Int(dateDayNumberFormatter.string(from: currentDate))!
  let CI: CalendarItem = CalendarItem(currentDate, julianDayNumber:currentJDN)
  
  // Day of week number: Sunday is 1.
  
  switch dayNumber
  {
  case 2: CL.mon = CI
  case 3: CL.tue = CI
  case 4: CL.wed = CI
  case 5: CL.thu = CI
  case 6: CL.fri = CI
  case 7: CL.sat = CI
  case 1: CL.sun = CI
   
  default: break
  }
 }
 
}

