//
//  CalendarLine.swift
//  WP-Cal
//
//  Created by busdev on 12/12/2017.
//  Copyright © 2017 FAV Software Limited. All rights reserved.
//

// Monthly calendar week.

import Foundation

class CalendarLine
{
 var lineType: String?
 var monthStr: String?
 var yearStr: String?
 
 var mon: CalendarItem?
 var tue: CalendarItem?
 var wed: CalendarItem?
 var thu: CalendarItem?
 var fri: CalendarItem?
 var sat: CalendarItem?
 var sun: CalendarItem?
 
 init()
 {
  self.lineType = ""
  self.monthStr = ""
  self.yearStr  = ""
 }
}
