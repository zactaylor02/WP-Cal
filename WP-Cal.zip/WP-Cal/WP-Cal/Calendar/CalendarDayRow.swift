//
//  CalendarDayRow.swift
//  WP-Cal
//
//  Created by busdev on 12/12/2017.
//  Copyright © 2017 FAV Software. All rights reserved.
//

import Foundation

class CalendarDayRow
{
 var calendarSlotDate: Date?
 var slotType: String?
 var slotDesc: String?
 
 init(_ calendarSlotDate: Date, slotType: String, slotDesc: String)
 {
  self.calendarSlotDate = calendarSlotDate
  self.slotType         = slotType
  self.slotDesc         = slotDesc
 }
}

