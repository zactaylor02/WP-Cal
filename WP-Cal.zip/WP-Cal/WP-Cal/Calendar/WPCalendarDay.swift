//
//  WPCalendarDay.swift
//  WP-Cal
//
//  Created by busdev on 12/12/2017.
//  Copyright © 2017 FAV Software. All rights reserved.
//

// Data source for daily calendar.

import UIKit
import CoreData

class WPCalendarDay: NSObject
{
 var updatingCalendarDayDataSource: Bool = false
 
 var ds  = [CalendarDayRow]()  // Data source pointer used by CalendarViewController.
 var dsCount: Int = 0
 
 let dateFormatter1  = DateFormatter()
 let dateFormatter3  = DateFormatter()
 let dateFormatter5  = DateFormatter()
 let dateFormatter10 = DateFormatter()
 
 let theDateFormat     = DateFormatter.Style.full
 let theTimeFormat     = DateFormatter.Style.none
 let theHourDateFormat = DateFormatter.Style.none
 let theHourTimeFormat = DateFormatter.Style.short
 
 var dateJDNFormatter: DateFormatter?     // Julian day number date formatter.
 var calendarDay1JDN: Int?                // Julian Day Number.
 var calendarDay2JDN: Int?                // Julian Day Number.
 var todayJDN: Int?                       // Today's Julian Day Number.
 var calendarStartDate: Date?
 var calendarEndDate: Date?
 
 override init()
 {
  super.init()
  
  dateFormatter1.dateFormat = "yyyyMMddHHmmss"
  dateFormatter1.locale = Locale(identifier: "en_US_POSIX")
  dateFormatter3.dateFormat = "yyyyMMdd"
  dateFormatter5.dateStyle  = theDateFormat
  dateFormatter5.timeStyle  = theTimeFormat
  dateFormatter10.dateStyle = theHourDateFormat
  dateFormatter10.timeStyle = theHourTimeFormat
 }
 
 func populateDataSourceWithSkeleton()
 {
  var slotDate: Date = calendarStartDate!
  
// Populate data source array, ds.
  
  let dateDesc: String = dateFormatter5.string(from: slotDate)
  let headerRow = CalendarDayRow(slotDate, slotType: k.kSlotTypeTitle, slotDesc: dateDesc)
  
  ds.append(headerRow)
  
  repeat
  {
   let slotDesc: String  = dateFormatter10.string(from: slotDate)
   let calendarDayRow: CalendarDayRow = CalendarDayRow(slotDate, slotType: k.kSlotTypeTime, slotDesc: slotDesc)
   
   ds.append(calendarDayRow)
   
   slotDate = slotDate.addHours(1) // Hourly slot dates.
  }
  while (slotDate.isBefore(calendarEndDate!) == true)
  
  dsCount = ds.count
 }
 
 func clearDataSource()
 {
  ds.removeAll()
 }
 
// Called from Calendar view controller.
 
 func updateCalendarDay(_ calendarDayJDN: Int)
 {
  printDbg(k.kDomainCalendarUI, str: "At updateCalendarDay().")
  
  updatingCalendarDayDataSource = true
  
  dateJDNFormatter = DateFormatter()
  dateJDNFormatter!.locale = Locale.current
  dateJDNFormatter!.dateFormat = "g"   // Julian date.
  
  let calendarDate = dateJDNFormatter!.date(from: "\(calendarDayJDN)")
  todayJDN = Int(dateJDNFormatter!.string(from: Date()))
  
// Set Calendar start date to 00:00 on the calendar day.
// Set Calendar end date to 23:59 on the calendar day.
  
  let startDateStr = dateFormatter3.string(from: calendarDate!) + "000000"
  calendarStartDate  = dateFormatter1.date(from: startDateStr)
  let endDateStr = dateFormatter3.string(from: calendarDate!) + "235900"
  calendarEndDate  = dateFormatter1.date(from: endDateStr)
  
  printDbg(k.kDomainCalendarUI, str: "Start date: \(startDateStr). End Date: \(endDateStr).")
  
  clearDataSource()
  populateCalendarDay()
  
  updatingCalendarDayDataSource = false
 }
 
 func populateCalendarDay()
 {
  populateDataSourceWithSkeleton()
 }
 
}

