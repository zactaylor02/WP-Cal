//
//  ViewController.swift
//  WP-Cal
//
//  Created by busdev on 12/12/2017.
//  Copyright © 2017 FAV Software. All rights reserved.
//

// Application created from assignment 5:
//
// "Create a custom Calendar for iOS where you can select any two days."

import UIKit

class ViewController: UIViewController {
 
 @IBAction func helpButtonPressed(_ sender: Any)
 {
  let kHelpStr: String = "Touch the Calendar label to enter the app."
  let tts: TTS = TTS()
  
  tts.textToSpeech(spokenStr: kHelpStr)
 }
 
 override func viewDidLoad() {
  super.viewDidLoad()
  // Do any additional setup after loading the view, typically from a nib.
 }

 override func didReceiveMemoryWarning() {
  super.didReceiveMemoryWarning()
  // Dispose of any resources that can be recreated.
 }


}

