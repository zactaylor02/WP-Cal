//
//  sharedCode.swift
//  WP-Cal
//
//  Created by busdev on 12/12/2017.
//  Copyright © 2017 FAV Software Limited. All rights reserved.
//

import Foundation
import UIKit

var debugApp: Bool = true  // *** Test ***

var debugDomains: [Int] = [k.kDomainSpeech,k.kDomainCalendarUI]

func printDbg(_ domain: Int, str: String)
{
 var domainFound: Bool = false
 
 if (debugApp == true)
 {
  if (debugDomains.isEmpty == false) && (domain != k.kDomainGeneral)
  {
   for i in 1...debugDomains.count
   {
    if (domain == debugDomains[i - 1])
    {
     domainFound = true
     break
    }
   }
  }
  
  if (domainFound == true) || (domain == k.kDomainGeneral)
  {
   print(str)
  }
 }
}

extension UIViewController
{
 var className: String
 {
  return NSStringFromClass(self.classForCoder).components(separatedBy: ".").last!
 }
}

extension Date
{
 
// Checks for current hour.
 
 func isToday() -> Bool
 {
  let cal = Calendar.current
  
  return cal.isDateInToday(self)
 }
 
 func isBefore(_ dateToCompare: Date) -> Bool
 {
  if self.compare(dateToCompare) == ComparisonResult.orderedAscending
  {
   return true
  }
  
  return false
 }
 
 func addYears(_ yearsToAdd: Int) -> Date
 {
  let cal = Calendar.current
  
  let newDate = (cal as NSCalendar).date(byAdding: .year, value: yearsToAdd, to: self,options: NSCalendar.Options(rawValue: 0))
  return newDate!
 }
 
 func addHours(_ hoursToAdd: Int) -> Date
 {
  let secondsInHours: TimeInterval = Double(hoursToAdd) * 60 * 60
  let dateWithHoursAdded: Date = self.addingTimeInterval(secondsInHours)
  
  return dateWithHoursAdded
 }
}

extension String
{
 
// Limits the length of a string, from the start of the string
// to maxLength characters.
 
 mutating func limitLength(_ maxLength: Int)
 {
  if (self.count > maxLength)
  {
   let rng = self.index(self.startIndex, offsetBy: maxLength)   // Set range from beginning of string.
   
   self = String(self[..<rng])   // Updated for Swift 4.
  }
 }
}

