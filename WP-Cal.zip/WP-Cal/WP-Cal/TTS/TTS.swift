//
//  TTS.swift
//  WP-Cal
//
//  Created 12/12/2017.
//  Copyright © 2017 FAV Software Limited. All rights reserved.
//

import UIKit
import AVFoundation

class TTS: NSObject, AVSpeechSynthesizerDelegate
{
 var ss: AVSpeechSynthesizer?
 var ttsVoice:AVSpeechSynthesisVoice!
 
// Constants.
 
 let kEnVoiceName: String = "SAMANTHA"   // KAREN, MOIRA, SAMANTHA, DANIEL.

/*
 Catherine
 Gordon
 Karen
 Arthur (Enhanced)
 Daniel (Enhanced)
 Arthur
 Daniel
 Martha
 Moira
*/
 
 override init()
 {
  super.init()
  
  let voices = AVSpeechSynthesisVoice.speechVoices()
  
  var currentLang = AVSpeechSynthesisVoice.currentLanguageCode()
  currentLang.limitLength(2)
  
  printDbg(k.kDomainGeneral, str: "Current language: \(currentLang)")
  
// If specific voice not found, the system default is automatically used.
  
  for voice in voices
  {
   var voiceLanguage = voice.language
   
   voiceLanguage.limitLength(2)
   
   if currentLang == voiceLanguage
   {
    printDbg(k.kDomainGeneral, str: "Voice name: \(voice.name).")
    
    if (currentLang == "en") && (voice.name.uppercased() == kEnVoiceName)
    {
     ttsVoice = voice
     break
    }
   }
  }
  createSynthesizer()
 }
 
 func createSynthesizer()
 {
  ss = AVSpeechSynthesizer()
  ss!.delegate = self
 }

 func textToSpeech(spokenStr: String)
 {
  printDbg(k.kDomainSpeech, str: "At textToSpeech()")
  
  let su: AVSpeechUtterance = AVSpeechUtterance.init(string: spokenStr)
  
  su.voice              = ttsVoice
  su.postUtteranceDelay = k.kPostUtteranceDelay
  su.preUtteranceDelay  = k.kPreUtteranceDelay
  su.rate               = AVSpeechUtteranceDefaultSpeechRate
  su.volume             = k.kMediumVolume
  su.pitchMultiplier    = 1.0    // Default value.
 
  if let _ = ss
  {
   printDbg(k.kDomainSpeech, str: "Speech synthesizer. Paused: \(ss!.isPaused). Speaking: \(ss!.isSpeaking).")
  
   if (ss!.isPaused == true)
   {
    ss!.continueSpeaking()
   }
  
   ss!.speak(su)
  }
  else
  {
   createSynthesizer()
   ss!.speak(su)
  }
 }
 
 func stopSpeaking()
 {
  if let _ = ss
  {
   if (ss!.isSpeaking)
   {
    ss!.stopSpeaking(at: .word)
   }
  }
 }
 
// Synthesizer protocol functions.
 
 func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance)
 {
  printDbg(k.kDomainSpeech, str: "At didCancel.")
 }
 
 func speechSynthesizer(_: AVSpeechSynthesizer, didContinue: AVSpeechUtterance)
 {
  printDbg(k.kDomainSpeech, str: "At didContinue.")
 }
 
 func speechSynthesizer(_: AVSpeechSynthesizer, didFinish: AVSpeechUtterance)
 {
  printDbg(k.kDomainSpeech, str: "At didFinish.")
 }
 
 func speechSynthesizer(_: AVSpeechSynthesizer, didPause: AVSpeechUtterance)
 {
  printDbg(k.kDomainSpeech, str: "At didPause.")
 }
 
 func speechSynthesizer(_: AVSpeechSynthesizer, didStart: AVSpeechUtterance)
 {
  printDbg(k.kDomainSpeech, str: "At didStart.")
 }
 
 func speechSynthesizer(_: AVSpeechSynthesizer, willSpeakRangeOfSpeechString: NSRange, utterance: AVSpeechUtterance)
 {
  printDbg(k.kDomainSpeech, str: "At willSpeakRangeOfSpeechString.")
 }
 
}
