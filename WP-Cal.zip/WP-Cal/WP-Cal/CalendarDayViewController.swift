//
//  CalendarDayViewController.swift
//  WP-Cal
//
//  Created by busdev on 12/12/2017.
//  Copyright © 2017 FAV Software Limited. All rights reserved.
//

import UIKit
import CoreData

class CalendarDayViewController: UIViewController,UITableViewDelegate,UITableViewDataSource
{
 @IBOutlet weak var screenTitle: UIBarButtonItem!
 @IBOutlet weak var calendarDayList: UITableView!
 @IBOutlet weak var headerLabel: UILabel!
 
 var dateJDNFormatter: DateFormatter?     // Julian day number date formatter.
 var calendarDay1JDN: Int = 0             // Julian Day Number. (Single tap).
 var calendarDay2JDN: Int = 0             // Julian Day Number. (Double tap).
 var todayJDN: Int?                       // Today's Julian Day Number.
 var pageHourStr: String?
 
 var day1DS: WPCalendarDay = WPCalendarDay()  // Single tap data source.
 var day2DS: WPCalendarDay = WPCalendarDay()  // Double tap data source.
 var ds = [CalendarDayRow]()                  // Combination of single and double tap data sources.
 
// Constants.
 
 let kHeaderHeight: CGFloat = 30  // 20.
 let kRowHeight: CGFloat    = 35  // 25.
 
 let kTitleFontSize: CGFloat = 18
 let kTimeFontSize: CGFloat  = 15

 let kDayTitle: String  = "Calendar Day"
 let kDaysTitle: String = "Calendar Days"

 override func viewDidLoad()
 {
  super.viewDidLoad()
  
// Do any additional setup after loading the view.
  
  calendarDayList.delegate   = self
  calendarDayList.dataSource = self
  
  printDbg(k.kDomainCalendarUI, str: "calendarDay1JDN: \(calendarDay1JDN). calendarDay2JDN: \(calendarDay2JDN).")

  dateJDNFormatter = DateFormatter()
  dateJDNFormatter!.locale = Locale.current
  dateJDNFormatter!.dateFormat = "g"   // Julian date.
  
   day1DS.updateCalendarDay(calendarDay1JDN)
  
// Account for case where user double and single taps on the same date.

  if (calendarDay2JDN != 0) && (calendarDay2JDN != calendarDay1JDN)
  {
   day2DS.updateCalendarDay(calendarDay2JDN)
   screenTitle.title = kDaysTitle
  }
  else
  {
   screenTitle.title = kDayTitle
  }
  
  todayJDN = Int(dateJDNFormatter!.string(from: Date()))
  
  populateDataSource()
  calendarDayList.reloadData()
 }
 
 override func didReceiveMemoryWarning()
 {
  super.didReceiveMemoryWarning()
     
// Dispose of any resources that can be recreated.
     
 }
    
 @IBAction func doneTapped(_ sender: AnyObject)
 {
  dismissView()
 }
 
// Populate table's data source.
// Make sure that the days are loaded in the correct order.
 
 func populateDataSource()
 {
  ds.removeAll()
  
  if (calendarDay2JDN != 0) && (calendarDay2JDN != calendarDay1JDN)
  {
   if (calendarDay2JDN > calendarDay1JDN) // Load Day1 first, then Day2.
   {
    for cr in day1DS.ds
    {
     ds.append(cr)
    }
    for cr in day2DS.ds
    {
     ds.append(cr)
    }
   }
   else                                   // Load Day2 first, then Day1.
   {
    for cr in day2DS.ds
    {
     ds.append(cr)
    }
    for cr in day1DS.ds
    {
     ds.append(cr)
    }
   }
  }
  else   // Load Day1 only.
  {
   for cr in day1DS.ds
   {
    ds.append(cr)
   }
  }
 }
 
// Table related functions.
 
// Returns number of calendar rows.
 
 func numberOfSections(in tableView: UITableView) -> Int
 {
  return ds.count
 }
 
 func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
 {
  let rowCount = 1
  
  return rowCount
 }
 
 func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
 {
  let cellIDStr = "cell"
  let cell: UITableViewCell = tableView.dequeueReusableCell(withIdentifier: cellIDStr)!
  
  return cell
 }
 
 func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView?
 {
  let view = UIView()
  let timeLabel = UILabel()
  
  timeLabel.text = ds[section].slotDesc!
  
  if (ds[section].slotType! == k.kSlotTypeTitle)
  {
   timeLabel.font = UIFont.systemFont(ofSize: kTitleFontSize)
   timeLabel.textColor = UIColor.black
  }
  else
  {
   timeLabel.font = UIFont.systemFont(ofSize: kTimeFontSize)
   timeLabel.textColor = UIColor.darkGray
  }
  
  timeLabel.translatesAutoresizingMaskIntoConstraints = false
  
  let views = ["timeLabel": timeLabel, "view": view]
  
  
  view.addSubview(timeLabel)
  
// Add contraints for hour labels.
// Hour label is left justified and 10 points from the left hand margin.
  
  let horizontalLayoutContraints1 = NSLayoutConstraint.constraints(withVisualFormat: "H:|-10-[timeLabel]->=10-|",
                                                    options: .alignAllCenterY,
                                                    metrics: nil,
                                                    views: views)
  
  view.addConstraints(horizontalLayoutContraints1)
  
  let verticalLayoutContraint1 = NSLayoutConstraint(item: timeLabel,
                                                    attribute: .centerY,
                                                    relatedBy: .equal,
                                                    toItem: view,
                                                    attribute: .centerY,
                                                    multiplier: 1, constant: 0)
  
  view.addConstraint(verticalLayoutContraint1)
  
  return view
 }
 
 
 func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
 {
  return kHeaderHeight
 }
 
 func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
 {
  return kRowHeight
 }
 
 func dismissView()
 {
  self.dismiss(animated: true, completion: nil)
 }
 
}
